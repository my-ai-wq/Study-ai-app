# Study Smart AI

A responsive, installable starter website for an AI tutor + study dashboard.

## Included
- AI chat using Gemini API via a Netlify Function
- Image and PDF attachment (PDF text extracted in browser)
- Browser voice input/output where supported
- Chat history, notes and task checklist saved in localStorage
- Study Zone and responsive mobile navigation
- Optional Google Search grounding in the function (`useSearch: true`; may not be included in free model tiers)

## Run locally
1. Install Node.js.
2. `npm install`
3. `npm run dev`
4. Open the local Netlify URL shown in terminal.

## Connect Gemini
For a quick personal test, open Settings in the app and paste a Gemini API key. This stores the key in that browser only and is not recommended for a public website.

For deployment:
1. Create a Gemini API key at https://aistudio.google.com/app/apikey
2. Deploy this folder to Netlify.
3. In Netlify: Site configuration → Environment variables, add `GEMINI_API_KEY`.
4. Redeploy. Do not put a shared production API key in frontend code.
5. Optional: set `GEMINI_MODEL` and `GEMINI_IMAGE_MODEL` environment variables to models available to your account.

Default text model: `gemini-3.8-flash`.
Default image model: `gemini-3.1-flash-lite-image`. Image generation availability/pricing depends on the account/model; it may not be free.

## Important limitations
- Voice uses the device/browser SpeechRecognition and SpeechSynthesis APIs; this is push-to-talk + spoken response, not Gemini's full-duplex Live API.
- Web Search currently opens Google Search in a new tab. The server function includes an optional Gemini Google Search grounding switch, but availability may depend on model and billing tier.
- Notes, tasks and chat history are device-local. There is no multi-user login, cloud sync, teacher/admin portal, database, or student account system yet.
- Add authentication, rate limits, server-side quotas, privacy notice and a database before making it public for students.
- Never expose your API key in a public repository or shared browser.

## Deploy
Drag the project folder (or connect its Git repository) in Netlify. Netlify's Free plan currently has monthly usage credits and hard limits; check the plan page before publishing to a large audience.
