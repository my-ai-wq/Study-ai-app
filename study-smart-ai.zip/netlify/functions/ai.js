const MODEL = process.env.GEMINI_MODEL || "gemini-3.8-flash";
const IMAGE_MODEL = process.env.GEMINI_IMAGE_MODEL || "gemini-3.1-flash-lite-image";
exports.handler = async (event) => {
  const headers = {"Access-Control-Allow-Origin":"*", "Access-Control-Allow-Headers":"Content-Type", "Access-Control-Allow-Methods":"POST,OPTIONS", "Content-Type":"application/json"};
  if (event.httpMethod === "OPTIONS") return {statusCode:204,headers,body:""};
  if (event.httpMethod !== "POST") return {statusCode:405,headers,body:JSON.stringify({error:"Method not allowed"})};
  try {
    const body=JSON.parse(event.body||"{}");
    const key=process.env.GEMINI_API_KEY || body.apiKey;
    if(!key) return {statusCode:400,headers,body:JSON.stringify({error:"Gemini API key is not configured. Add GEMINI_API_KEY in Netlify environment variables, or use the personal test key in Settings."})};
    const contents=body.contents||[];
    const model=body.imagePrompt?IMAGE_MODEL:MODEL;
    const payload={contents:body.imagePrompt?[{role:"user",parts:[{text:"Generate an image: "+body.imagePrompt}]}]:contents};
    if(body.imagePrompt) payload.generationConfig={responseModalities:["TEXT","IMAGE"]};
    if(body.useSearch && !body.imagePrompt) payload.tools=[{google_search:{}}];
    const url=`https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${encodeURIComponent(key)}`;
    const r=await fetch(url,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(payload)});
    const data=await r.json();
    if(!r.ok) return {statusCode:r.status,headers,body:JSON.stringify({error:data.error?.message||"Gemini API request failed"})};
    const parts=data.candidates?.[0]?.content?.parts||[];
    const text=parts.filter(p=>p.text).map(p=>p.text).join("\n");
    const images=parts.filter(p=>p.inlineData||p.inline_data).map(p=>{const x=p.inlineData||p.inline_data;return `data:${x.mimeType||x.mime_type};base64,${x.data}`});
    const sources=(data.candidates?.[0]?.groundingMetadata?.groundingChunks||[]).map(x=>x.web?.uri).filter(Boolean);
    return {statusCode:200,headers,body:JSON.stringify({text,images,sources})};
  } catch(e) { return {statusCode:500,headers,body:JSON.stringify({error:e.message||"Server error"})}; }
};